CREATE TABLE Pessoa(
	id int auto_increment,
	nome varchar(50) NOT NULL,
	qtd INTEGER NOT NULL,
	PRIMARY KEY (id)
);
