<?php
      
     require_once "mod_aluno.php"; 
     require_once "dbconexao.php";

     class ControleAluno {
        
        private $conexao = null;

        public function __construct(){
            $this->conexao = new Conexao();
        }
                 
        public function salvar($entrada){
            $sql = "insert into aluno (nome,prontuario) 
            values('{$entrada->getNome()}',
                   '{$entrada->getRegistro()}')";

            $this->conexao->execute($sql);  
        }


        public function alterar($entrada){
            $sql = "update aluno set nome='{$entrada->getNome()}' where prontuario='{$entrada->getRegistro()}'";
            $this->conexao->execute($sql);  
        }

        public function apagar($entrada){
            $sql = "delete from aluno  where prontuario='{$entrada->getRegistro()}'";
            $this->conexao->execute($sql);  
        }
     }
?>