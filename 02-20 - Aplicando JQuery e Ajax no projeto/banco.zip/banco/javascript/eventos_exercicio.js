


$(function(){    
    console.log("Documento carregado.."); // mensagens de depuracao
    
    
    
    
});
