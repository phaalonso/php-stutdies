<!DOCTYPE html>

     <html>
         <head>
             <meta charset="UTF-8">        
             <script src="javascript/jquery-3.4.1.min.js" type="text/javascript"></script>
             <script src="javascript/eventos_exercicio.js" type="text/javascript"></script>        
         </head>
         <body>
            
           <!-- <button id="bt" onclick=apagar()>Remover</button><br> -->
          <?php
               
               require_once "mod_aluno.php";
               require_once "controleAluno.php"; 

               $aluno = new Aluno();
               $daoAluno = new ControleAluno();

               $aluno->setNome($_POST["nomealuno"]);
               $aluno->setRegistro($_POST["reg"]);

               if(isset($_POST["bt1"])){
                   $daoAluno->salvar($aluno);
               }
                
               if(isset($_POST["bt2"])){
                   $daoAluno->alterar($aluno);
               }

               if(isset($_POST["bt3"])){
                   $daoAluno->apagar($aluno);
               }

               header("location:formulario.html");
          ?>

         </body>
<!--
          <script> 

          $(document).ready(() => {
               $("#T1").css("color","red");

               $(`
                        <div id="c1">
                            <label for="csm">Número do CSM</label>
                            <input type="text" name="csm" id="csm"></input>
                        </div>
                    `).insertAfter("#T1");
                 
          })

          function apagar(){
              $("c1").hide();
          }

          </script>
        -->
    </html>