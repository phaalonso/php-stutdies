<?php
   require_once "dbconexao.php";
   
   function montaTabela($entrada){
      $tabela = "<table border='1'>";
      for($i=0;$i<sizeof($entrada);$i++){
         $tabela.="<tr>";
         $tabela.="<td>{$entrada[$i]['prontuario']}</td>";  
         $tabela.="<td>{$entrada[$i]['nome']}</td>"; 
         $tabela.="<td>{$entrada[$i]['idade']}</td>";   
         $tabela.="<td>{$entrada[$i]['endereco']}</td>";  
         $tabela.="<td>{$entrada[$i]['email']}</td>";    
         $tabela.="</tr>";
      }
      $tabela.="</table>";
      return $tabela;
   }
   
   if($_POST["tipo"]==1){
      $dados = new Conexao();
      $str = $_REQUEST["numero"];
      $volta = $dados->executarSelect("select * from aluno where prontuario='{$str}'");
        
      if($volta==null){
          echo "Não encontrei";
        } else {
     
          echo json_encode($volta);

      }
   }

   if($_POST["tipo"]==2){
      $dados = new Conexao();
      $s1 = $_REQUEST["prontuario"];
      $s2 = $_REQUEST["nome"];
      $s3 = $_REQUEST["idade"];
      $s4 = $_REQUEST["endereco"];
      $s5 = $_REQUEST["email"];

      $sql = "insert into aluno (prontuario,nome,idade,endereco,email)
                        values ('{$s1}','{$s2}',{$s3},'{$s4}','{$s5}')";
                  
      $dados->execute($sql);
      $volta = $dados->executarSelect('select * from aluno');
      echo montaTabela($volta);

   } 

   if($_POST["tipo"]==3){
      $dados = new Conexao();     
      $volta = $dados->executarSelect('select * from aluno');
      echo montaTabela($volta);   
   } 

   if($_POST["tipo"]==4){
      $dados = new Conexao();
      $prontuario = $_REQUEST["numero"];

      $sql = "delete from aluno where prontuario='{$prontuario}'";
      $dados->execute($sql);
      $volta = $dados->executarSelect('select * from aluno');
      echo montaTabela($volta);
   
   } 

   if($_POST["tipo"]==5){
      $dados = new Conexao();
      $s1 = $_REQUEST["prontuario"];
      $s2 = $_REQUEST["nome"];
      $s3 = $_REQUEST["idade"];
      $s4 = $_REQUEST["endereco"];
      $s5 = $_REQUEST["email"];

      $sql = "update aluno set nome='{$s2}',
                               idade={$s3},
                               endereco='{$s4}',
                               email='{$s5}' where prontuario='{$s1}'";
                  
      $dados->execute($sql);
      $volta = $dados->executarSelect('select * from aluno');
      echo montaTabela($volta);
  
   } 
?>