<?php
     class Aluno {
         
        private $nome="";
        private $registro="";
        
        public function setNome($entrada){
            $this->nome = $entrada;
        }

        public function getNome(){
            return $this->nome;
        }

        public function setRegistro($entrada){
            $this->registro = $entrada;
        }

        public function getRegistro(){
            return $this->registro;
        }

     }
?>