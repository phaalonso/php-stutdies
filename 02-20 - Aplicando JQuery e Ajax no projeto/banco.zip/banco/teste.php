<?php
   require_once "dbconexao.php";

   print_r($_POST);
   $dados = new Conexao();
   $str = $_REQUEST["numero"];
   $volta = $dados->executarSelect("select * from aluno where prontuario='{$str}'");
   
   if($volta==null){
      echo "Não encontrei";
   } else {
      echo $volta[0]["nome"];
   }
   
?>