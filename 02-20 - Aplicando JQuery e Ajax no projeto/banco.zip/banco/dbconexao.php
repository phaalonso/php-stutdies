<?php
   class Conexao{
       private $conexao;
       private $banco;
       private $dados;
           
       public function conectar(){
           $this->conexao = mysqli_connect("localhost","root","xyzt4321");
           $this->banco = mysqli_select_db($this->conexao,"alunos");
           mysqli_set_charset($this->conexao,"utf8");
       }

       public function execute($sql){
           $this->conectar();
           $this->dados = mysqli_query($this->conexao,$sql);
          
       }

       public function executarSelect($sql){
           $this->conectar();
            $res = mysqli_query($this->conexao, $sql);  
            if ($res) {                          
                $dados = mysqli_fetch_all($res, MYSQLI_ASSOC);
            } else {                    
                $dados = array();  
            }        
            return $dados;
        }





       public function listar($campo){
           while($linha=mysqli_fetch_assoc($this->dados)){
               for($i=0;$i<sizeof($campo);$i++){
                  echo $linha[$campo[$i]]." ";
               }
               echo "<br>";
            }
       }

       public function retornaDados(){
           return $this->dados;
       }

       public function fecharConexao(){
           mysqli_close($this->conexao);   
       }
   }

   
?>
